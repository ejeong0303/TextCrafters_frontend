import { useEffect, useState, useRef } from "react";
import styled, { keyframes } from "styled-components";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faComment, faCheck } from "@fortawesome/free-solid-svg-icons";
import { MultiSelect } from "react-multi-select-component";
import { faThumbsUp, faThumbsDown } from "@fortawesome/free-solid-svg-icons";

import "./style.css";

const Result = () => {
  

  return (
    <>
      <img
        src="/img/textcraft_logo.png"
        style={{ width: "150px", marginTop: "30px" }}
      ></img>
      <Title>생성된 문구</Title>
      <MainBox>
        <TextBox>글자 수: 267</TextBox>
        <Button>
          <LongButton>다시 만들기</LongButton>
        </Button>
        <ResultBox>
          "아건" 레스토랑은 가격은 저렴하지 않지만 그만큼 훌륭한 식사 경험을
          제공합니다. 채광이 풍부하여 안락하고 환한 분위기를 즐길 수 있어요.
          음식은 맛있고, 특히 음식의 식감은 쫀득하면서도 살짝 매콤한 맛이
          돋보입니다. 레스토랑은 이국적인 분위기를 자랑하며, 현지에서 식사하는
          기분을 느낄 수 있어요. 식사 중에는 기분좋은 시간을 보낼 수 있는
          곳으로, "아건"은 가격, 서비스, 맛, 분위기 측면에서 다양한 측면에서
          만족스러운 레스토랑으로 꼽힙니다. 
        </ResultBox>
        <Copy>복사하기</Copy>
      </MainBox>
    </>
  );
};

const MainBox = styled.div`
  width: 390px;
  height: auto;
  margin: 0 auto;
`;
const Title = styled.div`
  font-size: 1.5rem;
  text-align: center;
  font-weight: 600;
  margin-top: 20px;
  color: #707e6c;
`;

const TextBox = styled.div`
  height: 35px;
  font-size: 12px;
  margin: 30px auto;
  width: 100px;
  font-size: 1rem;
  padding: 0 15px;
  border-radius: 60px;
  background-color: #f6f5f5;
  border: none;
  line-height: 2rem;
`;
const Button = styled.div`
  display: flex;
  justify-content: center;
  
`;
const ShortButton = styled.div`
  height: 35px;
  font-size: 12px;
  margin: 10px 20px;
  width: 70px;
  padding: 0 15px;
  border-radius: 60px;
  background-color: #d3e4cf;
  border: none;
  font-size: 1rem;
  line-height: 2rem;
  display: inline-block;
`;
const LongButton = styled.div`
  height: 35px;
  font-size: 12px;
  margin: 10px 20px;
  width: 90px;
  padding: 0 15px;
  border-radius: 60px;
  background-color: #d3e4cf;
  border: none;
  font-size: 1rem;
  line-height: 2rem;
  display: inline-block;
`;
const ResultBox = styled.div`
  width: 300px;
  background-color: #dbeff0;
  height: auto;
  box-shadow: 5px 5px 5px #e1eded;
  padding: 30px;
  line-height: 2rem;
  margin: 20px auto;
  border-radius: 20px;
`;
const Copy = styled.div`
  height: 40px;
  font-size: 12px;
  margin: 10px auto;
  width: 100px;

  padding: 0 15px;
  border-radius: 20px;
  background-color: #d3e4cf;
  border: none;
  font-size: 1rem;
  line-height: 2.5rem;
  display: inline-block;
`;

export default Result;
