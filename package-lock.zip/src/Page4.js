//import React from "react";
import React, { useState, useEffect } from "react";
import styled from "styled-components";
//import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';
import axios from "axios";

const Page4 = () => {
  const navigate = useNavigate();
  const [restaurant, setRestaurant] = useState(""); // State to store the restaurant name

  useEffect(() => {
    const storedRestaurant = sessionStorage.getItem("restaurant");
    if (storedRestaurant) {
      setRestaurant(storedRestaurant);
    }
  }, []);

  const handleInputChange = (event) => {
    const newRestaurant = event.target.value;
    setRestaurant(newRestaurant);
    sessionStorage.setItem("restaurant", newRestaurant); // Update session storage
  };

  const handleButtonClick = () => {
    axios
    .post("http://localhost:8000/api/keywords/", {
        restaurant: restaurant,
      })
      .then(function (response) {
        // Handle successful response
        console.log(response.data); // Log the response data to the console
        navigate('/select');
      })
      .catch(function (error) {
        // Handle error
        console.error("Error:", error);
      });
  };    

  return (
    <MainBox>
      <LogoContainer>
        <Logo src="logo512.png" alt="Logo" />
      </LogoContainer>
      <FormContainer>
        <InputLabel>가게 이름을 입력하세요</InputLabel>
        {/* Added value and onChange for controlled input */}
        <InputBox type="text" placeholder="예) 마포광안리" value={restaurant} onChange={handleInputChange} />
        {/* Added onClick to the button */}
        <OkButton onClick={handleButtonClick}>확인</OkButton>
      </FormContainer>
    </MainBox>
  );
};

const MainBox = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 390px;
  height: 844px;
  margin: 0 auto;
  background-color: white;
`;

const LogoContainer = styled.div`
  text-align: center;
  margin-bottom: 30px;
`;

const Logo = styled.img`
  width: 200px;
  height: auto;
`;

const FormContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 250px;
  margin-top: 20px;
  align-items: center;
  justify-content: center;
`;

const InputLabel = styled.div`
  font-size: 12px;
  color: black;
  margin-bottom: 5px;
`;

const InputBox = styled.input`
  width: 250px;
  height: 20px;
  border: none; 
  background-color: #f0f0f0; 
  border-radius: 5px;
  padding: 10px;
  margin-bottom: 10px;
  font-size: 12px;
`;

const OkButton = styled.button`
  border: none;
  border-radius: 10px;
  width: 120px; 
  height: 30px; 
  background-color: #D4E3CF; 
  color: black;
  margin-top: 20px; 
  cursor: pointer;
  font-size: 12px;
`;

export default Page4;
